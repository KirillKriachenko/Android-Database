package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

/**
 * Created by Kirill on 11/15/2017.
 */

public class Nurse {
    int nurseID;
    String firstName;
    String lastName;
    String department;
    String password;

    public Nurse(int nurseID, String firstName, String lastName, String department) {
        this.nurseID = nurseID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
    }

    public int getNurseID() {
        return nurseID;
    }

    public void setNurseID(int nurseID) {
        this.nurseID = nurseID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return getFirstName() + " " + getLastName();
    }
}
