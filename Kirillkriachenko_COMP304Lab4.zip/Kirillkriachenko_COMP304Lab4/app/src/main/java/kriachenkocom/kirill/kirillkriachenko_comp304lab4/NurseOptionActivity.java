package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class NurseOptionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nurse_option);
    }

    public void addTest(View view)
    {
        Intent intent = new Intent(this, AddTestActivity.class);
        this.startActivity(intent);
    }

    public void updateTest(View view)
    {
        Intent intent = new Intent(this, UpdateTestActivity.class);
        this.startActivity(intent);
    }
}
