package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

/**
 * Created by Kirill on 11/17/2017.
 */

public class Doctor {
    int doctorID;
    String firstName;
    String lastName;
    String department;

    public Doctor(int doctorID, String firstName, String lastName, String department) {
        this.doctorID = doctorID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
    }

    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return this.getFirstName() + " " + this.getLastName();
    }
}
