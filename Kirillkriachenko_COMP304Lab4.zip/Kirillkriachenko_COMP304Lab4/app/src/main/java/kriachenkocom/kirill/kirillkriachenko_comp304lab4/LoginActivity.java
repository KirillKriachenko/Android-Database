package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import org.json.JSONException;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {


    EditText editText;
    EditText editText2;

    CheckBox checkBox;


    //Переменная для работы с БД
    private DatabaseHelper mDBHelper;
    private SQLiteDatabase mDb;

    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editText = (EditText) findViewById(R.id.editText);
        editText2 = (EditText) findViewById(R.id.editText2);
        checkBox = (CheckBox) findViewById(R.id.checkBox);

        mDBHelper = new DatabaseHelper(this);

        try {
            mDBHelper.updateDataBase();
        } catch (IOException mIOException) {
            throw new Error("UnableToUpdateDatabase");
        }

        try {
            mDb = mDBHelper.getWritableDatabase();
        } catch (SQLException mSQLException) {
            throw mSQLException;
        }

    }

    public void loggin(View view)
    {
        if (checkBox.isChecked() == true)
        {
            try {
                Editable login = editText.getText();
                Editable password = editText2.getText();
                cursor = mDb.rawQuery("SELECT * FROM Nurse WHERE nurseid = '"+login+"' AND password = '"+password+"'; ",null);
                cursor.moveToFirst();
                if (cursor.moveToFirst() == true) {
                    Intent intent = new Intent(this, NurseOptionActivity.class);
                    cursor.close();
                    startActivity(intent);
                }
            }
            catch (Exception e)
            {

            }

        }
        else {
            try {
                Editable login = editText.getText();
                Editable password = editText2.getText();
                cursor = mDb.rawQuery("SELECT * FROM Doctor WHERE doctorid = '"+login+"' AND password = '"+password+"'; ",null);
                if (cursor.moveToFirst() == true) {
                    Intent intent = new Intent(this, PatientInfoActivity.class);
                    cursor.close();
                    startActivity(intent);
                }
                /*else if(cursor.moveToFirst() == false) {
                    AlertDialog alertDialog = new AlertDialog.Builder(LoginActivity.this).create();
                    alertDialog.setTitle("Alert");
                    alertDialog.setMessage("Incorrect login or password");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });

                } */
            }
            catch (Throwable e)
            {
            }
        }
    }
}
