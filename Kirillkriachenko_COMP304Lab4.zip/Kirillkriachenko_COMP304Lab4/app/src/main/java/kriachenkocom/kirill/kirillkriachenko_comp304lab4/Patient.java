package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

/**
 * Created by Kirill on 11/7/2017.
 */

public class Patient {
    private long patientId;
    private String firstName;
    private String lastName;
    private int department;
    private long doctorId;
    private int room;

    public Patient(long patientId, String firstName, String lastName, int department, long doctorId, int room) {
        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
        this.doctorId = doctorId;
        this.room = room;
    }

    public Patient(long patientId, String firstName, String lastName)
    {
        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public long getPatientId() {
        return patientId;
    }

    public void setPatientId(long patientId) {
        this.patientId = patientId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getDepartment() {
        return department;
    }

    public void setDepartment(int department) {
        this.department = department;
    }

    public long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(long doctorId) {
        this.doctorId = doctorId;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }
    @Override
    public String toString() {
        return getFirstName() + " " + getLastName();
    }
}
