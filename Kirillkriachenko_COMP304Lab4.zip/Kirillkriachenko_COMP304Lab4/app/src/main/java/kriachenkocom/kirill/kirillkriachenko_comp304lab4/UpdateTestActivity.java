package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UpdateTestActivity extends AppCompatActivity {

    private DatabaseHelper mDBHelper;
    private SQLiteDatabase mDb;

    Spinner patient_spinner;
    Spinner testSpinner;
    Spinner nurse_spinner;


    EditText bplText;
    EditText bphText;
    EditText temperatureText;
    EditText conclusionText;

    int testID;
    long patientID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_test);

        patient_spinner = (Spinner) findViewById(R.id.patient_pinner);
        testSpinner = (Spinner) findViewById(R.id.test_spinner);
        nurse_spinner = (Spinner) findViewById(R.id.nurse_spinner);

        bplText = (EditText) findViewById(R.id.bpl_text);
        bphText = (EditText) findViewById(R.id.bph_text);
        temperatureText = (EditText) findViewById(R.id.temperature_text);
        conclusionText = (EditText) findViewById(R.id.conclusion_text);


        mDBHelper = new DatabaseHelper(this);
        try {
            mDBHelper.updateDataBase();
        } catch (IOException mIOException) {
            throw new Error("UnableToUpdateDatabase");
        }

        try {
            mDb = mDBHelper.getWritableDatabase();
        } catch (SQLException mSQLException) {
            throw mSQLException;
        }


        final List<Patient> patientList = new ArrayList<>();
        final List<Test> testList = new ArrayList<>();

        try {
            Cursor patientCursor = mDb.rawQuery("SELECT * FROM Patient", null);
            patientCursor.moveToFirst();
            while (!patientCursor.isAfterLast()) {

                Patient patient = new Patient(patientCursor.getLong(0), patientCursor.getString(1), patientCursor.getString(2));
                patientList.add(patient);
                patientCursor.moveToNext();

            }

            ArrayAdapter<Patient> patientAdapter = new ArrayAdapter<Patient>(UpdateTestActivity.this, android.R.layout.simple_spinner_item, patientList);
            patientAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            patient_spinner.setAdapter(patientAdapter);
            patient_spinner.setPrompt("Title");
            patient_spinner.setSelection(0);
            patient_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    //Toast.makeText(getBaseContext(), "Position = " + position, Toast.LENGTH_SHORT).show();

                    patientID = patientList.get(position).getPatientId();
                    //Toast.makeText(getBaseContext(), Long.toString(patientID), Toast.LENGTH_SHORT).show();
                    Cursor cursor = mDb.rawQuery("SELECT * FROM Test WHERE patientid = '"+ patientID +"'", null);
                    cursor.moveToFirst();
                    while (!cursor.isAfterLast())
                    {
                        Test test = new Test(cursor.getInt(0),cursor.getInt(1),cursor.getString(2), cursor.getString(3),
                                cursor.getString(4), cursor.getString(5),cursor.getInt(6));
                        testList.add(test);
                        cursor.moveToNext();
                    }
                    ArrayAdapter<Test> adapter = new ArrayAdapter<Test>(UpdateTestActivity.this, android.R.layout.simple_spinner_item, testList);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    testSpinner.setAdapter(adapter);
                    testSpinner.setSelection(0);
                    testSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            testID = testList.get(position).getTestID();
                            bphText.setText(testList.get(position).getBph());
                            bplText.setText(testList.get(position).getBpl());
                            temperatureText.setText(testList.get(position).getTemperature());
                            conclusionText.setText(testList.get(position).getConclusion());
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
        catch (Exception e)
        {}


    }

    public void updateTest(View view)
    {
        ContentValues data = new ContentValues();
        data.put("BPL", String.valueOf(bplText.getText()));
        data.put("BPH",String.valueOf(bphText.getText()));
        data.put("temperature",String.valueOf(temperatureText.getText()));
        data.put("conclusion",String.valueOf(conclusionText.getText()));
        mDb.update("Test",data,"testid="+testID,null);
        this.finish();
        //String strSQL = "UPDATE Test SET BPL = someValue WHERE columnId = "+ someValue;

        //mDb.execSQL(strSQL);
    }
}

        /*
        final List<Nurse> nurseList = new ArrayList<>();
        try {
            Cursor cursorNurse = mDb.rawQuery("SELECT * FROM Nurse", null);
            cursorNurse.moveToFirst();
            while (!cursorNurse.isAfterLast()) {
                Nurse nurse = new Nurse(cursorNurse.getInt(0), cursorNurse.getString(1), cursorNurse.getString(2), cursorNurse.getString(3));
                nurseList.add(nurse);
                cursorNurse.moveToNext();
            }

            ArrayAdapter<Nurse> adapter = new ArrayAdapter<Nurse>(this, android.R.layout.simple_spinner_item, nurseList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            nurse_spinner.setAdapter(adapter);
            nurse_spinner.setPrompt("Title");
            nurse_spinner.setSelection(0);
            nurse_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    //Toast.makeText(getBaseContext(), "Position = " + position, Toast.LENGTH_SHORT).show();

                    nurseID = nurseList.get(position).getNurseID();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });


        catch (Exception e)
        {}
    }
}
*/