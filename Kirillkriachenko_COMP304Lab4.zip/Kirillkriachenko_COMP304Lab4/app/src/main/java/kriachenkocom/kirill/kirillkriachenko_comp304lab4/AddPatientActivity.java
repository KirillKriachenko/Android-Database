package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddPatientActivity extends AppCompatActivity {

    EditText firstName_text;
    EditText lastName_text;
    EditText department_text;
    EditText patientRoom_text;
    Spinner doctorName_spinner;

    int doctorID;

    private DatabaseHelper mDBHelper;
    private SQLiteDatabase mDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);

        firstName_text = (EditText) findViewById(R.id.firstName_text);
        lastName_text = (EditText) findViewById(R.id.lastName_text);
        department_text = (EditText) findViewById(R.id.department_text);
        patientRoom_text = (EditText) findViewById(R.id.patientRoom_text);
        doctorName_spinner = (Spinner) findViewById(R.id.doctorName_spinner);

        mDBHelper = new DatabaseHelper(this);
        try {
            mDBHelper.updateDataBase();
        } catch (IOException mIOException) {
            throw new Error("UnableToUpdateDatabase");
        }

        try {
            mDb = mDBHelper.getWritableDatabase();
        } catch (SQLException mSQLException) {
            throw mSQLException;
        }

        try {


            final List<Doctor> doctorList = new ArrayList<>();
            Cursor doctorCursor = mDb.rawQuery("SELECT * FROM Doctor", null);
            doctorCursor.moveToFirst();
            while (!doctorCursor.isAfterLast()) {
                Doctor doctor = new Doctor(doctorCursor.getInt(0), doctorCursor.getString(1),
                        doctorCursor.getString(2), doctorCursor.getString(3));
                doctorList.add(doctor);
                doctorCursor.moveToNext();
            }

            ArrayAdapter<Doctor> adapter = new ArrayAdapter<Doctor>(this, android.R.layout.simple_spinner_item, doctorList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            doctorName_spinner.setAdapter(adapter);
            doctorName_spinner.setSelection(0);
            doctorName_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    //Toast.makeText(getBaseContext(), "Position = " + position, Toast.LENGTH_SHORT).show();

                    doctorID = doctorList.get(position).getDoctorID();
                    department_text.setText(doctorList.get(position).getDepartment());
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
        catch (Throwable e)
        {}

    }

    public void addPatient(View view)
    {
        ContentValues data = new ContentValues();
        data.put("firstname",String.valueOf(firstName_text.getText()));
        data.put("lastname",String.valueOf(lastName_text.getText()));
        data.put("department",String.valueOf(department_text.getText()));
        data.put("room",String.valueOf(patientRoom_text.getText()));
        data.put("doctorid",String.valueOf(doctorID));

        mDb.insert("Patient", null,data);
        this.finish();
    }
}
