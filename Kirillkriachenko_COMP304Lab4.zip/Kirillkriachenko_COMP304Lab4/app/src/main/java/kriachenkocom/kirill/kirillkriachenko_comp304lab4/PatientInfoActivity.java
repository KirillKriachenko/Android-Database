package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.provider.ContactsContract;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PatientInfoActivity extends AppCompatActivity {


    private DatabaseHelper mDBHelper;
    private SQLiteDatabase mDb;

    Cursor cursor;
    Cursor listCursor;


    EditText patientID_text;
    TextView patientName;
    TextView patientDepartment;
    TextView patientRoom;
    ListView listView;
    TextView conclusion;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
        //return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.add_test:
                Intent intent = new Intent(this, AddTestActivity.class);
                cursor.close();
                listCursor.close();
                this.startActivity(intent);
                return true;

            case R.id.update_tet:
                Intent intent1 = new Intent(this, UpdateTestActivity.class);
                cursor.close();
                listCursor.close();
                this.startActivity(intent1);
                return true;

            case R.id.new_person:
                Intent intent2 = new Intent(this, AddPatientActivity.class);
                cursor.close();
                listCursor.close();
                this.startActivity(intent2);
                return true;

            case R.id.new_employee:
                Intent intent3 = new Intent(this, AddEmployeeActivity.class);
                cursor.close();
                listCursor.close();
                this.startActivity(intent3);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_info);

        mDBHelper = new DatabaseHelper(this);
        try {
            mDBHelper.updateDataBase();
        } catch (IOException mIOException) {
            throw new Error("UnableToUpdateDatabase");
        }

        try {
            mDb = mDBHelper.getWritableDatabase();
        } catch (SQLException mSQLException) {
            throw mSQLException;
        }

        conclusion = (TextView) findViewById(R.id.conclusionText);
        patientName = (TextView) findViewById(R.id.textView5) ;
        patientDepartment = (TextView) findViewById(R.id.patientDepartment);
        patientRoom = (TextView) findViewById(R.id.patientRoom);

        patientID_text = (EditText) findViewById(R.id.idText);
        patientID_text.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                final List<Test> testList = new ArrayList<>();
                try {
                    cursor = mDb.rawQuery("SELECT * FROM Patient WHERE patientid = " + patientID_text.getText(), null);
                    cursor.moveToFirst();

                    patientName.setText(cursor.getString(1));
                    patientDepartment.setText(cursor.getString(3));
                    patientRoom.setText(cursor.getString(4));



                    listView = (ListView) findViewById(R.id.testList);
                    listCursor = mDb.rawQuery("SELECT * FROM Test WHERE patientid = " + patientID_text.getText(),null);
                    listCursor.moveToFirst();
                    while (!listCursor.isAfterLast()) {

                        Test test = new Test(listCursor.getString(2),listCursor.getString(3),listCursor.getString(4),listCursor.getString(5));
                        testList.add(test);
                        //product += cursor.getString(1) + " | ";
                        listCursor.moveToNext();
                    }




                    /*ArrayAdapter<Test> arrayAdapter = new ArrayAdapter<Test>(PatientInfoActivity.this,
                            R.layout.activity_patient_info,testList);
                    listView.setAdapter(arrayAdapter); */
                    //fillListView();
                    ArrayAdapter<Test> adapter = new ArrayAdapter<Test>(PatientInfoActivity.this,android.R.layout.simple_list_item_1,testList);
                    listView.setAdapter(adapter);

                }
                catch (Exception e)
                {}

              listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                  @Override
                  public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                      Toast.makeText(getApplicationContext(),
                              "Click ListItem Number " + position, Toast.LENGTH_LONG)
                              .show();

                      conclusion.setText(testList.get(position).getConclusion());
                  }
              });

            }


            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }


    public void fillListView()
    {
        List<Test> testList = new ArrayList<>();

        listView = (ListView) findViewById(R.id.testList);
        Cursor listCursor = mDb.rawQuery("SELECT * FROM Test WHERE patientid = " + patientID_text.getText(),null);
        listCursor.moveToFirst();
        while (!listCursor.isAfterLast()) {

            Test test = new Test(listCursor.getString(2),listCursor.getString(3),listCursor.getString(4),listCursor.getString(5));
            testList.add(test);
            //product += cursor.getString(1) + " | ";
            listCursor.moveToNext();
        }

        ArrayAdapter<Test> arrayAdapter = new ArrayAdapter<Test>(this,
                R.layout.activity_patient_info,testList);
        listView.setAdapter(arrayAdapter);
    }



}
