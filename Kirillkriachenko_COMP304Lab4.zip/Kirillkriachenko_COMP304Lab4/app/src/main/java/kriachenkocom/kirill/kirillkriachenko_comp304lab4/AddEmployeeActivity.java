package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

import android.content.ContentValues;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import java.io.IOException;

public class AddEmployeeActivity extends AppCompatActivity {

    EditText firstName_text;
    EditText lastName_text;
    EditText department_text;
    EditText password_text;
    CheckBox isNurse_chb;

    private DatabaseHelper mDBHelper;
    private SQLiteDatabase mDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);

        firstName_text = (EditText) findViewById(R.id.firstName_text);
        lastName_text = (EditText) findViewById(R.id.lastName_text);
        department_text = (EditText) findViewById(R.id.department_text);
        password_text = (EditText) findViewById(R.id.password_text);
        isNurse_chb = (CheckBox) findViewById(R.id.nurse_chb);

        mDBHelper = new DatabaseHelper(this);
        try {
            mDBHelper.updateDataBase();
        } catch (IOException mIOException) {
            throw new Error("UnableToUpdateDatabase");
        }

        try {
            mDb = mDBHelper.getWritableDatabase();
        } catch (SQLException mSQLException) {
            throw mSQLException;
        }

    }
    public void addEmployee(View view)
    {
        String chooseTable;

        ContentValues data = new ContentValues();
        data.put("firstname",String.valueOf(firstName_text.getText()));
        data.put("lastname",String.valueOf(lastName_text.getText()));
        data.put("department",String.valueOf(department_text.getText()));
        data.put("password",String.valueOf(password_text.getText()));

        if (isNurse_chb.isChecked())
        {
            chooseTable = "Nurse";
            mDb.insert(chooseTable,null,data);
        }
        else {
            chooseTable = "Doctor";
            mDb.insert(chooseTable,null,data);
        }
        this.finish();
    }
}
