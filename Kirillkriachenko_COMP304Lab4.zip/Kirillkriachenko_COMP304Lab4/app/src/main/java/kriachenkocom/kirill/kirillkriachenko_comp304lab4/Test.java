package kriachenkocom.kirill.kirillkriachenko_comp304lab4;

/**
 * Created by Kirill on 11/10/2017.
 */
public class Test {

    int testID;
    int patientID;
    int nurseID;
    String bpl;
    String bph;
    String temperature;
    String conclusion;

    public Test(String bpl, String bph, String temperature, String conclusion) {
        this.bpl = bpl;
        this.bph = bph;
        this.temperature = temperature;
        this.conclusion = conclusion;
    }

    public Test(int testID) {
        this.testID = testID;
    }

    public Test(int testID, int patientID, String bpl, String bph, String temperature, String conclusion,int nurseID) {
        this.testID = testID;
        this.patientID = patientID;
        this.nurseID = nurseID;
        this.bpl = bpl;
        this.bph = bph;
        this.temperature = temperature;
        this.conclusion = conclusion;
    }

    public int getTestID() {
        return testID;
    }

    public void setTestID(int testID) {
        this.testID = testID;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public int getNurseID() {
        return nurseID;
    }

    public void setNurseID(int nurseID) {
        this.nurseID = nurseID;
    }

    public String getBpl() {
        return bpl;
    }

    public void setBpl(String bpl) {
        this.bpl = bpl;
    }

    public String getBph() {
        return bph;
    }

    public void setBph(String bph) {
        this.bph = bph;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getConclusion() {
        return conclusion;
    }

    public void setConclusion(String conclusion) {
        this.conclusion = conclusion;
    }

    @Override
    public String toString() {
        return " BPL: " +this.bpl.toString() + " BPH: " + this.bph.toString() + " t: " + this.temperature.toString();
    }

}
